var dbconfig = {};

var redis = {};

var config = {}

dbconfig.host = 'hashkorea.myds.me'
dbconfig.user = 'root'
dbconfig.password = 'hashmanager'
dbconfig.database = 'today'
dbconfig.port = 32814


redis.host = 'hashkorea.myds.me'
redis.port = '32815'

config.dbconfig = dbconfig
config.redis = redis
const gwt = {
    SECRET: 'gotlzhfldk#dksdmswls'
    , EXPIRES: '7d'
    , REFRESH_EXPIRES: '30d'
    , REFRESH_SECRET: 'gotlzhfldk#dldmsdn'
    , AUDIENCE: "coincore"
    , ISSUER: "coincore"
}

config.gwt = gwt

const mail = {
    sender: '',
    user: '',
    pass: ''
}

config.mail = mail
module.exports = config;  
